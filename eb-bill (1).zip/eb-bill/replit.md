# PowerCalc India - Replit Project Setup

## Project Overview
PowerCalc India is a comprehensive electricity bill calculator web application for all Indian states and union territories. It provides accurate bill calculations, energy-saving recommendations, and detailed tariff information.

## Architecture
- **Frontend**: Vanilla HTML, CSS, and JavaScript
- **Type**: Static web application (no backend required)
- **Hosting**: Simple HTTP server

## Setup Completed
1. ✅ Python 3.11 installed for serving static files
2. ✅ Workflow configured to serve on port 5000 using Python's HTTP server
3. ✅ Application tested and working properly
4. ✅ Deployment configured for autoscale deployment target

## Key Features
- State-wise electricity tariff calculations for 10+ Indian states
- Interactive calculator with step-by-step process
- Detailed bill breakdown and analysis  
- Energy efficiency recommendations
- FAQ and glossary sections
- Responsive design with dark/light mode support

## Project Structure
- `index.html` - Main application page
- `app.js` - Application logic and calculator functionality  
- `style.css` - Comprehensive styling with dark mode support

## Running the Application
The application runs automatically via the configured workflow:
```bash
python -m http.server 5000
```

## Deployment
Configured for autoscale deployment with Python HTTP server serving static files on port 5000.

## Recent Changes
- Initial setup completed on September 3, 2025
- All static files serving properly
- JavaScript functionality verified working
- No build process required - ready to deploy